package main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

import main.Robot.Action;

/**
 * Our implementation of the Depth-First Search.
 */
public class DFS extends Algorithm {

	protected Stack<Path> openStates;

	public DFS(Grid grid)
	{
		this.grid = grid;
		this.openStates = new Stack<Path>();
		this.closedStates = new LinkedList<Path>();
		this.nodesWhichSucked = new ArrayList<Path>();
	}

	@Override
	protected List<Path> computeSolution() {

		Robot robot = this.grid.getRobot();
		Path firstNode = new Path(robot, 0);
		Path finalNode = null;
		
		this.openStates.push(firstNode);
		
		while (!this.openStates.isEmpty() && finalNode == null)
		{
			Path current = this.openStates.pop();
			this.closedStates.add(current);
			
			// SUCCESSOR FUNCTION
			this.computeSuccessors(current);
		}
		
		Collections.sort(nodesWhichSucked, new Comparator<Path>()
		{
			public int compare(Path p1, Path p2)
			{
				return Integer.compare(p2.getCellsAlreadyCleaned().size(), p1.getCellsAlreadyCleaned().size());
			}
		});
		
		Path finalPath = null;
		if (nodesWhichSucked.isEmpty())
		{
			finalPath = firstNode;
		}
		else
		{
			finalPath = nodesWhichSucked.get(0);
		}
		
		LinkedList<Path> solution = new LinkedList<Path>();
		while (finalPath != null)
		{
			solution.addFirst(finalPath);
			finalPath = finalPath.parent;
		}
		
		return solution;
	}

	@Override
	protected void computeSuccessors(Path current)
	{
		Robot tempBot;
		Path newPath;
		
		// For DFS performance reasons, we reverse the order of the Actions
		List<Action> reversedActions = Arrays.asList(Action.values().clone());
        Collections.reverse(reversedActions);
        
		for (Action action : reversedActions)
		{
			tempBot = new Robot(current.roboClone);
			newPath = null;
			
			switch (action)
			{
				case LEFT: case RIGHT:
					tempBot.turn(action);
					newPath = new Path(current, tempBot, action, current.cost
							+ Action.cost(action), current.getCellsAlreadyCleaned());
					break;
				
				case MOVE:
					Position newPosition = tempBot.getCellInFrontOfRobot();
					Cell cellInFront;
					try
					{
						cellInFront = grid.getCell(newPosition);
						if (cellInFront.isObstructed())
							continue;
					}
					catch (OutOfBoundsException e)
					{
						continue;
					}
					
					tempBot.setPosition(newPosition);
					newPath = new Path(current, tempBot, action, current.cost 
							+ Action.cost(action), current.getCellsAlreadyCleaned());
					break;
				
				case SUCK:
					// WE ARE NOT ACTUALLY IMPACTING THE GRID DURING A
					// SEARCH
					
					Position cleanBotPosition = tempBot.getPosition();
					Cell cell = null;
					try
					{
						cell = grid.getCell(cleanBotPosition);
					}
					catch (OutOfBoundsException e)
					{
						continue;
					}
					
					if (!cell.isDirty() || current.getCellsAlreadyCleaned().contains(cell))
					{
						continue;
					}
					else
					{
						newPath = new Path(current, tempBot, action, current.cost
								+ Action.cost(action), current.getCellsAlreadyCleaned());
						nodesWhichSucked.add(newPath);
						newPath.addCleanedCell(cell);
					}
					break;
			}
			
			if (!(openStates.contains(newPath) || closedStates.contains(newPath)))
			{
				openStates.push(newPath);
			}
		}
	}
}
