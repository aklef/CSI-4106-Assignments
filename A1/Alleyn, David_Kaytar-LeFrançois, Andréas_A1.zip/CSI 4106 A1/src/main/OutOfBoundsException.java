package main;

public class OutOfBoundsException extends Exception
{

	public OutOfBoundsException(String string)
	{
		super(string);
	}

	/**
	 * Randomly generated...
	 */
	private static final long serialVersionUID = 4322124373968424877L;
}
